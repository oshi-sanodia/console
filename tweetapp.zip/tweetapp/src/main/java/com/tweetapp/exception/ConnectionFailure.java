package com.tweetapp.exception;

public class ConnectionFailure extends Exception {

	public ConnectionFailure() {
		// TODO Auto-generated constructor stub
	}

	public ConnectionFailure(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ConnectionFailure(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ConnectionFailure(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ConnectionFailure(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}

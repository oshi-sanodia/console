package com.tweetapp.exception;

public class forgotPasswordFailure extends Exception {

	public forgotPasswordFailure() {
		// TODO Auto-generated constructor stub
	}

	public forgotPasswordFailure(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public forgotPasswordFailure(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public forgotPasswordFailure(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public forgotPasswordFailure(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}

package com.tweetapp.exception;

public class AddTweetFailure extends Exception {

	public AddTweetFailure() {
		// TODO Auto-generated constructor stub
	}

	public AddTweetFailure(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public AddTweetFailure(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public AddTweetFailure(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AddTweetFailure(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}

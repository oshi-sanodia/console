package com.tweetapp.exception;

public class GetAllTweetFailure extends Exception {

	public GetAllTweetFailure() {
		// TODO Auto-generated constructor stub
	}

	public GetAllTweetFailure(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public GetAllTweetFailure(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public GetAllTweetFailure(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public GetAllTweetFailure(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}

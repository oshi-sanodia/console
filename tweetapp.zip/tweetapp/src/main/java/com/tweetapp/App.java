package com.tweetapp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.tweetapp.bean.RegisterBean;
import com.tweetapp.exception.AddTweetFailure;
import com.tweetapp.exception.AddUserFailure;
import com.tweetapp.exception.ConnectionFailure;
import com.tweetapp.exception.GetAllTweetFailure;
import com.tweetapp.exception.GetTweetFailure;
import com.tweetapp.exception.LoginFailure;
import com.tweetapp.exception.forgotPasswordFailure;
import com.tweetapp.bean.LoginBean;
import com.tweetapp.service.RegisterService;
import com.tweetapp.service.RegisterServiceImpl;

/**
 * mvn compile mvn exec:java -Dexec.mainClass=com.tweetapp.App 
 */
public class App {
	public static void main(String[] args) throws NumberFormatException, IOException, ParseException {
		System.out.println("Welcome to Tweet App!");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		SimpleDateFormat df = new SimpleDateFormat("mm/dd/yyyy");
		df.setLenient(false);
		while (true) {
			System.out.println("PRESS 1 to Register");
			System.out.println("PRESS 2 to Login");
			System.out.println("PRESS 3 if you Forgot Password");
			System.out.println("PRESS 4 to Exit Tweet App");
			System.out.println("________________________________________");
			try {
				int c = Integer.parseInt(br.readLine());
				if (c == 1) {
					// register //post method
					System.out.println("Enter your First Name:");
					String ufName = br.readLine();
					System.out.println("Enter your Last Name:");
					String ulName = br.readLine();
					System.out.println("Enter your Gender m/f:");
					String gender = br.readLine();
					System.out.println("Enter Date in format (mm/dd/yyyy):");
					String dateString = br.readLine();
					Date date = df.parse(dateString);
					System.out.println("Enter your Email:");
					String email = br.readLine();
					System.out.println("Enter your Password:");
					String password1 = br.readLine();
					RegisterBean rb = new RegisterBean(ufName, ulName, gender, date, email, password1);
					RegisterService rs = new RegisterServiceImpl();
					boolean answer = false;
					try {
						answer = rs.register(rb);
					} catch (AddUserFailure e) {
						System.out.println(e.getMessage());
					} catch (ConnectionFailure e) {
						System.out.println(e.getMessage());
					}
					if (answer) {
						System.out.println("Registration done Successfully. Login to Continue");
						System.out.println("________________________________________");
					} else {
						System.out.println("Something went Wrong. Try Again");
					}
				} else if (c == 2) {
					// login
					System.out.println("Enter your Email:");
					String email = br.readLine();
					System.out.println("Enter your Password:");
					String password1 = br.readLine();
					LoginBean rb = new LoginBean(email, password1);
					RegisterService res = new RegisterServiceImpl();
					boolean answer = false;
					try {
						answer = res.login(rb);
					} catch (ConnectionFailure e) {
						System.out.println(e.getMessage());
					} catch (LoginFailure e) {
						System.out.println(e.getMessage());
					}
					if (answer) {
						System.out.println("Login done Successfully");
						System.out.println("________________________________________");

						while (true) {
							System.out.println("PRESS 1 to Post a new Tweet");
							System.out.println("PRESS 2 to View my Tweets");
							System.out.println("PRESS 3 to View all Tweets");
							System.out.println("PRESS 4 to View all Users");
							System.out.println("PRESS 5 to Reset Your Password");
							System.out.println("PRESS 6 to Logout");
							System.out.println("________________________________________");
							try {
								int d = Integer.parseInt(br.readLine());
								if (d == 1) {
									// post tweet
									System.out.println("Post your tweet:");
									String tweet = br.readLine();
									RegisterService regs = new RegisterServiceImpl();
									boolean ans = false;
									try {
										ans = regs.postTweet(email, tweet);
									} catch (ConnectionFailure e) {
										System.out.println(e.getMessage());
									} catch (AddTweetFailure e) {
										System.out.println(e.getMessage());
									}
									if (ans) {
										System.out.println("Tweet posted Successfully");
										System.out.println("________________________________________");
									} else {
										System.out.println("Something went Wrong. Try Again");
									}
								}

								else if (d == 2) {
									// view all tweet of logged in user
									List<String> list = new ArrayList<>();
									RegisterService regs = new RegisterServiceImpl();
									try {
										list = regs.viewMyTweets(email);
									} catch (ConnectionFailure e) {
										System.out.println(e.getMessage());
									} catch (GetTweetFailure e) {
										System.out.println(e.getMessage());
									}
									// STREAM MAP()
									list.stream().map(n -> "Tweet: " + n + "\n" + "====================")
											.forEach(System.out::println);
								}

								else if (d == 3) {
									// view tweets of all registered users
									List<String> list = new ArrayList<>();
									RegisterService rs = new RegisterServiceImpl();
									try {
										list = rs.viewAllTweets();
									} catch (ConnectionFailure e) {
										System.out.println(e.getMessage());
									} catch (GetAllTweetFailure e) {
										System.out.println(e.getMessage());
									}
									// LAMBDA EXPRESSION
									list.forEach((n) -> System.out.println(n + "\n" + "===================="));
								}

								else if (d == 4) {
									// view all registered user
									List<String> list = new ArrayList<>();
									RegisterService rs = new RegisterServiceImpl();
									list = rs.viewAllUsers();
									// LAMBDA EXPRESSION
									list.forEach((n) -> System.out.println(n + "\n" + "===================="));
								}

								else if (d == 5) {
									// reset password
									System.out.println("Enter your old Password:");
									String pass = br.readLine();
									System.out.println("Enter your new Password:");
									String npass = br.readLine();
									RegisterService rese = new RegisterServiceImpl();
									boolean ans = rese.reset(email, pass, npass);
									System.out.println(ans);
									if (ans == true) {
										System.out.println("Password Reset Successfully");
										System.out.println("________________________________________");
									} else if (ans == false) {
										System.out.println("Wrong Credentials. Try Again");
									}

								} else if (d == 6) {
									break;
								} else {
									System.out.println("Invalid Input. Refer below options");
								}
							} catch (NumberFormatException nfe) {
								System.out.println("Your input is not a number. Enter number from below options");
							}

						}
						System.out.println("Loggout Successfully");

					} else {
						System.out.println("You have entered wrong credentials. Try Again");
					}

				} else if (c == 3) {
					// forgot password
					System.out.println("Enter your Email:");
					String email = br.readLine();
					System.out.println("Enter your new Password:");
					String password = br.readLine();
					RegisterService res = new RegisterServiceImpl();
					boolean ans = false;
					try {
						ans = res.forgot(email, password);
					} catch (ConnectionFailure e) {
						System.out.println(e.getMessage());
					} catch (forgotPasswordFailure e) {
						System.out.println(e.getMessage());
					}
					if (ans) {
						System.out.println("Password Changed Successfully");
						System.out.println("________________________________________");
					} else {
						System.out.println("Wrong Credentials. Try Again");
					}

				} else if (c == 4) {
					break;
				} else {
					System.out.println("Invalid Input. Refer below options");
				}
			} catch (NumberFormatException nfe) {
				System.out.println("Your input is not a number. Enter number from below options");
			} catch (IOException ioe) {
				System.out.println("Something went Wrong. Try Again");
			} catch (ParseException pe) {
				System.out.println("Please Enter Date in Required Format (mm/dd/yyyy)");
			}
		}
		System.out.println("Thank You for using Tweet App!!");
	}
}

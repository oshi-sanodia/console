package com.tweetapp.dao;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.tweetapp.bean.LoginBean;
import com.tweetapp.bean.RegisterBean;
import com.tweetapp.exception.AddTweetFailure;
import com.tweetapp.exception.AddUserFailure;
import com.tweetapp.exception.ConnectionFailure;
import com.tweetapp.exception.GetAllTweetFailure;
import com.tweetapp.exception.GetTweetFailure;
import com.tweetapp.exception.LoginFailure;
import com.tweetapp.exception.forgotPasswordFailure;

public class RegisterDaoImp implements RegisterDao {
	static Connection con;
	String season = null;
	Object obb = null;

	public static Properties loadPropertiesFile() throws Exception {
		Properties prop = new Properties();
		InputStream in = new FileInputStream("target/classes/db.properties");
		prop.load(in);
		in.close();
		return prop;
	}

	public static Connection createConnection() throws ConnectionFailure {
		try {
			Properties prop;
			prop = loadPropertiesFile();

			String driverClass = prop.getProperty("MYSQLJDBC.driver");
			String url = prop.getProperty("MYSQLJDBC.url");
			String username = prop.getProperty("MYSQLJDBC.username");
			String password = prop.getProperty("MYSQLJDBC.password");

			Class.forName(driverClass);

			con = DriverManager.getConnection(url, username, password);
		} catch (Exception e) {
			throw new ConnectionFailure("Connection not established", e.getCause());
		}
		return con;

	}

	public boolean addUser(RegisterBean rb) throws AddUserFailure, ConnectionFailure {
		// REGISTER
		boolean f = false;
		try {
			Connection con = null;
			try {
				con = createConnection();
			} catch (ConnectionFailure e) {
				throw new ConnectionFailure(e.getMessage(), e.getCause());
			}
			String q = "insert into users(first_name,last_name,gender,dob,email,password) values (?,?,?,?,?,?)";
			PreparedStatement pstmt;
			pstmt = con.prepareStatement(q);

			pstmt.setString(1, rb.getFirstName());
			pstmt.setString(2, rb.getLastName());
			pstmt.setString(3, rb.getGender());

			java.util.Date utilDate = rb.getDob();
			java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

			pstmt.setDate(4, sqlDate);
			pstmt.setString(5, rb.getEmail());
			pstmt.setString(6, rb.getPassword());
			pstmt.executeUpdate();
			f = true;
			return f;
		} catch (SQLException e) {
			throw new AddUserFailure("Error:User Not Added", e.getCause());
		}

		finally {

			try {

				if (con != null) {

					con.close();

				}

			}

			catch (Exception e) {

				e.printStackTrace();

			}

		}

	}

	public boolean validate(LoginBean loginBean) throws ConnectionFailure, LoginFailure {
		// LOGIN
		boolean status = false;
		try {
			Connection con = null;
			try {
				con = createConnection();
			} catch (ConnectionFailure e) {
				throw new ConnectionFailure(e.getMessage(), e.getCause());
			}

			String q = "select first_name,last_name,gender,email,password from users where email=? and password=?";
			PreparedStatement pstmt = con.prepareStatement(q);
			pstmt.setString(1, loginBean.getEmail());
			pstmt.setString(2, loginBean.getPassword());
			ResultSet rs = pstmt.executeQuery();
			status = rs.next();

		} catch (SQLException e) {
			throw new LoginFailure("Error:Login Failed", e.getCause());
		} finally {

			try {

				if (con != null) {

					con.close();

				}

			}

			catch (Exception e) {

				e.printStackTrace();

			}

		}
		return status;
	}

	public boolean addTweet(String em, String tw) throws ConnectionFailure, AddTweetFailure {
		// POST NEW TWEET
		boolean status = false;

		try {
			Connection con;
			try {
				con = createConnection();
			} catch (ConnectionFailure e) {
				throw new ConnectionFailure(e.getMessage(), e.getCause());
			}
			String q = "insert into tweets(email,user_tweet) values (?,?)";
			PreparedStatement pstmt = con.prepareStatement(q);
			pstmt.setString(1, em);
			pstmt.setString(2, tw);
			pstmt.executeUpdate();
			status = true;

		} catch (SQLException e) {

			throw new AddTweetFailure("Error:Fail to post Tweet", e.getCause());

		} finally {

			try {

				if (con != null) {

					con.close();

				}

			}

			catch (Exception e) {

				e.printStackTrace();

			}

		}
		return status;

	}

	public List<String> getMyTweets(String em) throws ConnectionFailure, GetTweetFailure {
		// GET MY TWEET
		List<String> list = new ArrayList<>();

		try {
			Connection con;
			try {
				con = createConnection();
			} catch (ConnectionFailure e) {
				throw new ConnectionFailure(e.getMessage(), e.getCause());
			}

			String q = "select tweet_id, email, user_tweet from tweets where email=?";
			PreparedStatement pstmt = con.prepareStatement(q);
			pstmt.setString(1, em);

			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String tweet = rs.getString(3);
				list.add(tweet);
			}

		} catch (SQLException e) {
			throw new GetTweetFailure("Error:Fail to get tweets", e.getCause());
		} finally {

			try {

				if (con != null) {

					con.close();

				}

			}

			catch (Exception e) {

				e.printStackTrace();

			}

		}
		return list;

	}

	public List<String> getAllTweets() throws ConnectionFailure, GetAllTweetFailure {
		// GET ALL TWEETS
		List<String> list = new ArrayList<>();
		try {
			Connection con;
			try {
				con = createConnection();
			} catch (ConnectionFailure e) {
				throw new ConnectionFailure(e.getMessage(), e.getCause());
			}
			String q = "select * from tweets";
			PreparedStatement pstmt = con.prepareStatement(q);
			ResultSet set = pstmt.executeQuery(q);
			while (set.next()) {
				String email = set.getString(2);
				String tweets = set.getString(3);
				list.add(email + " " + "Tweet:" + tweets);
			}

		} catch (SQLException e) {
			throw new GetAllTweetFailure("Error:Fail to get all tweets", e.getCause());
		} finally {

			try {

				if (con != null) {

					con.close();

				}

			}

			catch (Exception e) {

				e.printStackTrace();

			}

		}
		return list;

	}

	public List<String> getAllUsers() {
		// GET ALL USERS
		List<String> list = new ArrayList<>();
		try {
			Connection con = createConnection();
			String q = "select * from users";

			PreparedStatement pstmt = con.prepareStatement(q);

			ResultSet set = pstmt.executeQuery(q);
			while (set.next()) {
				String fname = set.getString(2);
				String lname = set.getString(3);

				list.add("Name:" + fname + " " + lname);

			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {

				if (con != null) {

					con.close();

				}

			}

			catch (Exception e) {

				e.printStackTrace();

			}

		}
		return list;

	}

	public boolean forgetPassword(String email, String password) throws ConnectionFailure, forgotPasswordFailure {
		// FORGOT PASSWORD
		boolean status = false;

		try {
			Connection con = null;
			try {
				con = createConnection();
			} catch (ConnectionFailure e) {
				throw new ConnectionFailure(e.getMessage(), e.getCause());
			}
			String q = "update users set password=? where email=?";
			PreparedStatement pstmt = con.prepareStatement(q);
			pstmt.setString(1, password);
			pstmt.setString(2, email);
			int i = pstmt.executeUpdate();
			if (i > 0) {
				status = true;
			} else {
				status = false;
			}

		} catch (SQLException e) {

			throw new forgotPasswordFailure("Error:Fail to forgot password to set to new one", e.getCause());

		} finally {

			try {

				if (con != null) {

					con.close();

				}

			}

			catch (Exception e) {

				e.printStackTrace();

			}

		}
		return status;

	}

	public boolean resetPassword(String email, String password, String npassword) {
		// RESET PASSWORD
		boolean status = false;

		try {
			Connection con = null;
			try {
				con = createConnection();
			} catch (ConnectionFailure e) {
				e.printStackTrace();
			}
			String q = "update users set password=? where email=? and password=?";
			PreparedStatement pstmt = con.prepareStatement(q);
			pstmt.setString(1, npassword);
			pstmt.setString(2, email);
			pstmt.setString(3, password);
			int i = pstmt.executeUpdate();
			if (i > 0) {
				status = true;
			} else {
				status = false;
			}

		} catch (SQLException e) {

			printSQLException(e);

		} finally {

			try {

				if (con != null) {

					con.close();

				}

			}

			catch (Exception e) {

				e.printStackTrace();

			}

		}
		return status;

	}

	public boolean userNameExists(String email) throws ConnectionFailure {
		// CHECK DUPLICATE USERNAME
		List<String> list = new ArrayList<>();
		boolean status = false;

		try {
			Connection con;
			try {
				con = createConnection();
			} catch (ConnectionFailure e) {
				throw new ConnectionFailure(e.getMessage(), e.getCause());
			}

			String q = "select first_name,last_name,gender,email,password from users where email=?";
			PreparedStatement pstmt = con.prepareStatement(q);
			pstmt.setString(1, email);

			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String fname = rs.getString(2);
				String lname = rs.getString(3);

				list.add("Name:" + fname + " " + lname);

			}
			if (list.isEmpty()) {
				status = true;
			} else {
				status = false;
			}

		} catch (SQLException e) {
			e.printStackTrace();

		} finally {

			try {

				if (con != null) {

					con.close();

				}

			}

			catch (Exception e) {

				e.printStackTrace();

			}

		}
		return status;

	}

	private void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}

	}

}

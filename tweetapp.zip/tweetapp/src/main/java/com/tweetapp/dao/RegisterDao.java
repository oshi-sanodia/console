package com.tweetapp.dao;

import java.util.List;
import com.tweetapp.bean.LoginBean;
import com.tweetapp.bean.RegisterBean;
import com.tweetapp.exception.AddTweetFailure;
import com.tweetapp.exception.AddUserFailure;
import com.tweetapp.exception.ConnectionFailure;
import com.tweetapp.exception.GetAllTweetFailure;
import com.tweetapp.exception.GetTweetFailure;
import com.tweetapp.exception.LoginFailure;
import com.tweetapp.exception.forgotPasswordFailure;

public interface RegisterDao {

	public boolean addUser(RegisterBean rb) throws AddUserFailure, ConnectionFailure;

	public boolean validate(LoginBean rb) throws ConnectionFailure, LoginFailure;

	public boolean addTweet(String em, String tw) throws ConnectionFailure, AddTweetFailure;

	public List<String> getMyTweets(String em) throws ConnectionFailure, GetTweetFailure;

	public List<String> getAllTweets() throws ConnectionFailure, GetAllTweetFailure;

	public List<String> getAllUsers();

	public boolean forgetPassword(String email, String password) throws ConnectionFailure, forgotPasswordFailure;

	public boolean resetPassword(String email, String password, String npassword);

	public boolean userNameExists(String email) throws ConnectionFailure;

}

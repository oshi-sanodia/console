package com.tweetapp.service;

import java.util.List;
import com.tweetapp.bean.RegisterBean;
import com.tweetapp.bean.LoginBean;
import com.tweetapp.dao.RegisterDao;
import com.tweetapp.dao.RegisterDaoImp;
import com.tweetapp.exception.AddTweetFailure;
import com.tweetapp.exception.AddUserFailure;
import com.tweetapp.exception.ConnectionFailure;
import com.tweetapp.exception.GetAllTweetFailure;
import com.tweetapp.exception.GetTweetFailure;
import com.tweetapp.exception.LoginFailure;
import com.tweetapp.exception.forgotPasswordFailure;

public class RegisterServiceImpl implements RegisterService {

	public boolean register(RegisterBean rb) throws AddUserFailure, ConnectionFailure {
		// REGISTER
		boolean result = false;
		boolean answer = false;
		RegisterDao registerDao = new RegisterDaoImp();
		String fname = rb.getFirstName();
		String lname = rb.getLastName();
		String gender = rb.getGender();
		String email = rb.getEmail();

		if (!(fname.matches("[a-zA-Z]+"))) {
			System.out.println("Your name is containing characters other than alphabets.Check your input and Please enter correct details");
			result = false;
			return result;
		}
		if (!(lname.matches("[a-zA-Z]+"))) {
			System.out.println("Your name is containing characters other than alphabets.Check your input and Please enter correct details");
			result = false;
			return result;
		}
		if (!(gender.matches("[a-zA-Z]+"))) {
			System.out.println("Your gender is containing characters other than alphabets.Check your input and Please enter correct details m or f");
			result = false;
			return result;
		}

		if (!((gender.equals("m")) || (gender.equals("f")) || (gender.equals(" ")))) {
			System.out.println("Your gender should contain only alphabets m or f");
			result = false;
			return result;
		}

		boolean res = emailValidator(rb.getEmail());
		if (!res) {
			System.out.print("You Have entered incorrect email address please enter again");
			result = false;
			return result;
		}

		boolean b = registerDao.userNameExists(email);
		if (b == false) {
			System.out.println("Sorry username already Exists. Try with another one");
			result = false;
			return result;
		}

		result = passwordValidator(rb.getPassword());
		if (!result) {
			System.out.println("Your password should have 6 to 20 charaters and Must contain at least one digit and Must contain at least one of the following special characters @, #, $");
			return result;
		}

		try {
			if (result) {
				answer = registerDao.addUser(rb);
			}
		} catch (AddUserFailure e) {
			throw new AddUserFailure(e.getMessage(), e.getCause());
		} catch (ConnectionFailure e) {
			throw new ConnectionFailure(e.getMessage(), e.getCause());
		}
		if (answer) {
			return true;
		} else {
			return false;
		}
	}

	public boolean login(LoginBean rb) throws ConnectionFailure, LoginFailure {
		// LOGIN
		RegisterDao registerDao = new RegisterDaoImp();
		boolean answer = false;
		try {
			answer = registerDao.validate(rb);
		} catch (ConnectionFailure e) {
			throw new ConnectionFailure(e.getMessage(), e.getCause());
		} catch (LoginFailure e) {
			throw new LoginFailure(e.getMessage(), e.getCause());
		}
		if (answer) {
			return true;
		} else {
			return false;
		}

	}

	public boolean postTweet(String em, String tw) throws ConnectionFailure, AddTweetFailure {
		// POST TWEET
		RegisterDao registerDao = new RegisterDaoImp();
		boolean answer = false;
		boolean call = false;
		try {
			if (tw.length() > 280) {
				System.out.println("You have exceeded the length of tweet");
				call = false;
				return false;
			}
			if (tw.isEmpty()) {
				System.out.println("You Cannot post Empty tweet");
				call = false;
				return false;
			}
			if (!call) {
				answer = registerDao.addTweet(em, tw);
			}
		} catch (ConnectionFailure e) {
			throw new ConnectionFailure(e.getMessage(), e.getCause());
		} catch (AddTweetFailure e) {
			throw new AddTweetFailure(e.getMessage(), e.getCause());
		}
		if (answer) {
			return true;
		} else {
			return false;
		}

	}

	public List<String> viewMyTweets(String em) throws ConnectionFailure, GetTweetFailure {
		// VIEW MY TWEETS
		RegisterDao registerDao = new RegisterDaoImp();
		try {
			return registerDao.getMyTweets(em);
		} catch (ConnectionFailure e) {
			throw new ConnectionFailure(e.getMessage(), e.getCause());
		} catch (GetTweetFailure e) {
			throw new GetTweetFailure(e.getMessage(), e.getCause());
		}

	}

	public List<String> viewAllTweets() throws ConnectionFailure, GetAllTweetFailure {
		// VIEW ALL TWEETS
		List<String> ls = null;
		RegisterDao registerDao = new RegisterDaoImp();
		try {
			ls = registerDao.getAllTweets();
		} catch (ConnectionFailure e) {
			throw new ConnectionFailure(e.getMessage(), e.getCause());
		} catch (GetAllTweetFailure e) {
			throw new GetAllTweetFailure(e.getMessage(), e.getCause());
		}
		return ls;
	}

	public List<String> viewAllUsers() {
		// VIEW ALL USERS
		RegisterDao registerDao = new RegisterDaoImp();
		return registerDao.getAllUsers();
	}

	public boolean forgot(String email, String password) throws ConnectionFailure, forgotPasswordFailure {
		// FORGOT PASSWORD
		boolean result = false;
		boolean answer = false;
		result = passwordValidator(password);
		if (!result) {
			System.out.println(
					"Your password should have 6 to 20 charaters and Must contain at least one digit and Must contain at least one of the following special characters @, #, $");
			return result;
		}
		RegisterDao registerDao = new RegisterDaoImp();

		try {
			if (result) {
				answer = registerDao.forgetPassword(email, password);
			}
		} catch (ConnectionFailure e) {
			throw new ConnectionFailure(e.getMessage(), e.getCause());
		} catch (forgotPasswordFailure e) {
			throw new forgotPasswordFailure(e.getMessage(), e.getCause());
		}
		if (answer) {
			return true;
		} else {
			return false;
		}
	}

	public boolean reset(String email, String password, String npassword) {
		// RESET PASSWORD
		boolean result = false;
		boolean answer = false;
		result = passwordValidator(npassword);
		if (!result) {
			System.out.println(
					"Your password should have 6 to 20 charaters and Must contain at least one digit and Must contain at least one of the following special characters @, #, $");
			return result;
		}
		RegisterDao registerDao = new RegisterDaoImp();
		if (result) {
			answer = registerDao.resetPassword(email, password, npassword);
		}
		if (answer == true) {
			answer = true;
			return answer;
		} else if (answer == false) {
			answer = false;
			return answer;
		}
		return answer;
	}

	boolean emailValidator(String email) {
		String ePattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
		java.util.regex.Pattern p = java.util.regex.Pattern.compile(ePattern);
		java.util.regex.Matcher m = p.matcher(email);
		return m.matches();
	}

	boolean passwordValidator(String password) {
		boolean result = false;
		if (password.matches(".*[0-9]{1,}.*") && password.matches(".*[@#$]{1,}.*") && password.length() >= 6
				&& password.length() <= 20) {
			result = true;
		} else {
			result = false;

		}

		return result;

	}

}

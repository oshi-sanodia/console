package com.tweetapp.service;

import com.tweetapp.bean.RegisterBean;
import com.tweetapp.exception.AddTweetFailure;
import com.tweetapp.exception.AddUserFailure;
import com.tweetapp.exception.ConnectionFailure;
import com.tweetapp.exception.GetAllTweetFailure;
import com.tweetapp.exception.GetTweetFailure;
import com.tweetapp.exception.LoginFailure;
import com.tweetapp.exception.forgotPasswordFailure;
import com.tweetapp.bean.LoginBean;
import java.util.List;

public interface RegisterService {

	public boolean register(RegisterBean rb) throws AddUserFailure, ConnectionFailure;

	public boolean login(LoginBean rb) throws ConnectionFailure, LoginFailure;

	public boolean postTweet(String em, String tw) throws ConnectionFailure, AddTweetFailure;

	public List<String> viewMyTweets(String em) throws ConnectionFailure, GetTweetFailure;

	public List<String> viewAllTweets() throws ConnectionFailure, GetAllTweetFailure;

	public List<String> viewAllUsers();

	public boolean forgot(String email, String password) throws ConnectionFailure, forgotPasswordFailure;

	public boolean reset(String email, String password, String npassword);

}
